import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { completeAssessment } from "../utils/storage";

export default function Assessment() {
	const navigate = useNavigate();

	const submitAssessment = () => {
		completeAssessment();

		alert("Assessment Submitted Successfully");

		navigate("/dashboard");
	};

	return (
		<>
			<Navbar />

			<div className="dashboard">
				<h1>Online Assessment</h1>

				<div className="welcome-card">
					<h2>Java Technical Test</h2>

					<p>Duration : 30 Minutes</p>

					<p>Total Questions : 20</p>

					<p>Passing Score : 60%</p>

					<br />

					<button onClick={submitAssessment}>Submit Assessment</button>
				</div>
			</div>

			<Footer />
		</>
	);
}
