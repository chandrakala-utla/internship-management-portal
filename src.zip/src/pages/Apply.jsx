function Apply() {
	return (
		<h1 style={{ textAlign: "center", marginTop: "100px" }}>Apply Page</h1>
	);
}

export default Apply;
