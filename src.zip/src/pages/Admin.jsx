import { useState } from "react";
import AdminNavbar from "../components/AdminNavbar";
import Footer from "../components/Footer";
import "../styles/admin.css";

import { getAllApplications, updateApplicationStatus } from "../utils/storage";

export default function Admin() {
	const [applications, setApplications] = useState(getAllApplications());

	const updateStatus = (index, status) => {
		updateApplicationStatus(index, status);
		setApplications(getAllApplications());
	};

	const totalStudents = new Set(applications.map((a) => a.email)).size;

	const applied = applications.filter((a) => a.status === "Applied").length;

	const assessment = applications.filter(
		(a) => a.status === "Assessment Assigned",
	).length;

	const interview = applications.filter(
		(a) =>
			a.status === "Technical Interview" || a.status === "Interview Scheduled",
	).length;

	const selected = applications.filter((a) => a.status === "Selected").length;

	const rejected = applications.filter((a) => a.status === "Rejected").length;

	return (
		<>
			<AdminNavbar />

			<div className="admin-container">
				<h1>Admin Dashboard</h1>

				<div className="stats">
					<div className="card">
						<h2>{totalStudents}</h2>
						<p>Students</p>
					</div>

					<div className="card">
						<h2>{applications.length}</h2>
						<p>Applications</p>
					</div>

					<div className="card">
						<h2>{applied}</h2>
						<p>Applied</p>
					</div>

					<div className="card">
						<h2>{assessment}</h2>
						<p>Assessment</p>
					</div>

					<div className="card">
						<h2>{interview}</h2>
						<p>Interview</p>
					</div>

					<div className="card">
						<h2>{selected}</h2>
						<p>Selected</p>
					</div>

					<div className="card">
						<h2>{rejected}</h2>
						<p>Rejected</p>
					</div>
				</div>

				<div className="table-box">
					<h2>Applications</h2>

					<table>
						<thead>
							<tr>
								<th>Student</th>

								<th>Company</th>

								<th>Role</th>

								<th>Status</th>

								<th>Update</th>
							</tr>
						</thead>

						<tbody>
							{applications.length === 0 ?
								<tr>
									<td colSpan="5">No Applications</td>
								</tr>
							:	applications.map((app, index) => (
									<tr key={index}>
										<td>{app.name}</td>

										<td>{app.company}</td>

										<td>{app.role}</td>

										<td>{app.status}</td>

										<td>
											<select
												value={app.status}
												onChange={(e) => updateStatus(index, e.target.value)}
											>
												<option>Applied</option>

												<option>Resume Approved</option>

												<option>Assessment Assigned</option>

												<option>Technical Interview</option>

												<option>Selected</option>

												<option>Rejected</option>
											</select>
										</td>
									</tr>
								))
							}
						</tbody>
					</table>
				</div>
			</div>

			<Footer />
		</>
	);
}
