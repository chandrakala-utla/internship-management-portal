import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import "../styles/dashboard.css";
import { useNavigate } from "react-router-dom";
import { getApplications } from "../utils/storage";

export default function Dashboard() {
    const navigate = useNavigate();

		const applications = getApplications();

		const applied = applications.length;

		const shortlisted = applications.filter(
			(app) => app.status === "Shortlisted",
		).length;

		const interviews = applications.filter(
			(app) => app.status === "Interview",
		).length;

		const offers = applications.filter(
			(app) => app.status === "Selected",
		).length;
	const stats = [
		{
			title: "Applied",
			value: applied,
			icon: "📄",
		},
		{
			title: "Shortlisted",
			value: shortlisted,
			icon: "🎯",
		},
		{
			title: "Interviews",
			value: interviews,
			icon: "💬",
		},
		{
			title: "Offers",
			value: offers,
			icon: "🏆",
		},
	];

	return (
		<>
			<Navbar />

			<div className="dashboard">
				<div className="welcome-card">
					<h1>👋 Welcome Back</h1>
					<p>Keep learning, keep applying and land your dream internship.</p>
				</div>

				<div className="stats-grid">
					{stats.map((item, index) => (
						<div className="stat-box" key={index}>
							<div className="stat-icon">{item.icon}</div>
							<h2>{item.value}</h2>
							<p>{item.title}</p>
						</div>
					))}
				</div>

				<div className="quick-actions">
					<h2>Quick Actions</h2>

					<div className="action-buttons">
						<button onClick={() => navigate("/internships")}>
							Browse Internships
						</button>

						<button onClick={() => navigate("/applications")}>
							My Applications
						</button>

						<button onClick={() => navigate("/register")}>
							Update Profile
						</button>
					</div>
				</div>
				<div className="assessment-section">
					<h2>Assessment</h2>

					{(
						applications.filter(
							(app) => app.assessmentAssigned && !app.assessmentCompleted,
						).length === 0
					) ?
						<p>No assessments available.</p>
					:	applications
							.filter(
								(app) => app.assessmentAssigned && !app.assessmentCompleted,
							)
							.map((app, index) => (
								<div className="assessment-card" key={index}>
									<h3>{app.company}</h3>

									<p>{app.role}</p>

									<button onClick={() => navigate(`/assessment/${index}`)}>
										Start Assessment
									</button>
								</div>
							))
					}
				</div>
				<div className="progress-section">
					<h2>Application Progress</h2>

					<div className="progress-item">
						<span>Google</span>
						<div className="bar">
							<div className="fill fill1"></div>
						</div>
						<span>Selected</span>
					</div>

					<div className="progress-item">
						<span>Microsoft</span>
						<div className="bar">
							<div className="fill fill2"></div>
						</div>
						<span>Interview</span>
					</div>

					<div className="progress-item">
						<span>Amazon</span>
						<div className="bar">
							<div className="fill fill3"></div>
						</div>
						<span>Applied</span>
					</div>
				</div>

				<div className="recent-table">
					<h2>Recent Applications</h2>

					<table>
						<thead>
							<tr>
								<th>Company</th>
								<th>Role</th>
								<th>Status</th>
							</tr>
						</thead>

						<tbody>
							{applications.length === 0 ?
								<tr>
									<td colSpan="3">No applications yet.</td>
								</tr>
							:	applications.map((item, index) => (
									<tr key={index}>
										<td>{item.company}</td>
										<td>{item.role}</td>
										<td>
											<p
												className={item.status
													.toLowerCase()
													.replace(/\s/g, "-")}
											>
												{item.status}
											</p>

											{item.status === "Assessment Assigned" && (
												<button onClick={() => navigate("/assessment")}>
													Take Assessment
												</button>
											)}

											{item.status === "Interview Scheduled" && (
												<button onClick={() => navigate("/interview")}>
													Join Interview
												</button>
											)}
										</td>
									</tr>
								))
							}
						</tbody>
					</table>
				</div>
			</div>

			<Footer />
		</>
	);
}
