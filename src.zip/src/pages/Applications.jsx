import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { getApplications } from "../utils/storage";
import "../styles/applications.css";

export default function Applications() {
	const applications = getApplications();

	return (
		<>
			<Navbar />

			<div className="applications-page">
				<h1>My Applications</h1>

				{applications.length === 0 ?
					<p className="empty">You haven't applied for any internships yet.</p>
				:	<table>
						<thead>
							<tr>
								<th>Company</th>
								<th>Role</th>
								<th>Status</th>
							</tr>
						</thead>

						<tbody>
							{applications.map((app, index) => (
								<tr key={index}>
									<td>{app.company}</td>
									<td>{app.role}</td>
									<td>{app.status}</td>
								</tr>
							))}
						</tbody>
					</table>
				}
			</div>

			<Footer />
		</>
	);
}
