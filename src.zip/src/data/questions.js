const questions = [
	{
		question: "Which keyword is used to inherit a class in Java?",
		options: ["implements", "extends", "inherits", "super"],
		answer: "extends",
	},
	{
		question: "Which company developed React?",
		options: ["Google", "Facebook", "Microsoft", "Oracle"],
		answer: "Facebook",
	},
	{
		question: "Which HTML tag is used for hyperlinks?",
		options: ["<a>", "<link>", "<href>", "<url>"],
		answer: "<a>",
	},
	{
		question: "Which SQL command retrieves data?",
		options: ["INSERT", "SELECT", "UPDATE", "DELETE"],
		answer: "SELECT",
	},
	{
		question: "Which language runs in the browser?",
		options: ["Java", "Python", "JavaScript", "C++"],
		answer: "JavaScript",
	},
	{
		question: "CSS stands for?",
		options: [
			"Creative Style Sheets",
			"Cascading Style Sheets",
			"Computer Style Sheets",
			"Colorful Style Sheets",
		],
		answer: "Cascading Style Sheets",
	},
	{
		question: "Which hook manages state in React?",
		options: ["useEffect", "useState", "useRef", "useMemo"],
		answer: "useState",
	},
	{
		question: "Which database is relational?",
		options: ["MongoDB", "Firebase", "MySQL", "Redis"],
		answer: "MySQL",
	},
	{
		question: "HTTP status code for success?",
		options: ["200", "404", "500", "301"],
		answer: "200",
	},
	{
		question: "Which company owns Java?",
		options: ["Oracle", "Microsoft", "Google", "IBM"],
		answer: "Oracle",
	},
];

export default questions;
