import { Link, useNavigate } from "react-router-dom";
import { isLoggedIn, logout, getCurrentUser } from "../utils/storage";

function Navbar() {
	const navigate = useNavigate();
	const user = getCurrentUser();

	const handleLogout = () => {
		logout();
		navigate("/");
	};

	return (
		<nav className="navbar">
			<div className="logo">
				<span className="logo-icon">🎓</span>
				<span>Internship Portal</span>
			</div>

			<ul>
				<li>
					<Link to="/">Home</Link>
				</li>

				<li>
					<Link to="/internships">Internships</Link>
				</li>

				{isLoggedIn() && (
					<>
						<li>
							<Link to="/dashboard">Dashboard</Link>
						</li>

						<li>
							<Link to="/applications">Applications</Link>
						</li>

						<li className="username">Hi, {user?.name?.toUpperCase()}</li>

						<li>
							<button className="logout-btn" onClick={handleLogout}>
								Logout
							</button>
						</li>
					</>
				)}

				{!isLoggedIn() && (
					<>
						<li>
							<Link to="/login">Login</Link>
						</li>

						<li>
							<Link to="/register">Register</Link>
						</li>
					</>
				)}
			</ul>
		</nav>
	);
}

export default Navbar;
