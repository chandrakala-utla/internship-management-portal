import { Link, useNavigate } from "react-router-dom";
import { logout } from "../utils/storage";

export default function AdminNavbar() {
	const navigate = useNavigate();

	const handleLogout = () => {
		logout();
		navigate("/login");
	};

	return (
		<nav className="navbar">
			<div className="logo">
				🎓 <span>Internship Portal | Admin</span>
			</div>

			<ul>
				<li>
					<Link to="/admin">Dashboard</Link>
				</li>

				<li>
					<Link to="/admin/applications">Applications</Link>
				</li>

				<li>
					<button className="logout-btn" onClick={handleLogout}>
						Logout
					</button>
				</li>
			</ul>
		</nav>
	);
}
